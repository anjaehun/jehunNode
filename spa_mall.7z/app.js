const express = require("express");  // express 패키지 파일 불러오기 
const app = express(); 
const port = 3000; 

app.get('/',(req, res) => {
    res.send("Hello World@@@@");
})

app.listen(port, () => {
   console.log(port, "포트로 서버가 켜졌어요!");
}); 

